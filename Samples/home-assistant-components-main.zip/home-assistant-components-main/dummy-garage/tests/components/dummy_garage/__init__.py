"""Tests for the Dummy Garage integration."""
