"""Constants for the Dummy Garage integration."""

DOMAIN = "dummy_garage"
