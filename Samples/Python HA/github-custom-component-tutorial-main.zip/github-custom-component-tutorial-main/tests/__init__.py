"""Tests for the github-custom custom component."""
